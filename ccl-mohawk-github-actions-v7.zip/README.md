# CCL Mohawk Finder v3 — Oracle Cloud Always Free

This is a **clue-aware, bounded website monitor**, not a guaranteed autonomous puzzle solver. It follows selected CCL links, finds possible Mohawk clues, and sends an urgent email for a PC with a structured GBP £1.00 product offer. No login, checkout, CAPTCHA bypass, proxy rotation, or payment collection. It respects robots.txt and stops a scan cycle on 403/429. Check CCL promotion terms before enabling.

## Free cloud deployment (Oracle Ubuntu VM)
1. Create an Oracle Cloud Always Free account and provision an **Always Free eligible** Ubuntu VM (Ampere A1 if available). Choose your home region and avoid non-free resources.
2. Connect over SSH. Install: `sudo apt update && sudo apt install -y python3 python3-venv python3-pip unzip`.
3. Upload this project's files (e.g. with SCP) to the VM. Then:
   ```bash
   sudo useradd --system --home /opt/ccl-mohawk --shell /usr/sbin/nologin mohawk
   sudo mkdir -p /opt/ccl-mohawk
   sudo cp -r bot.py requirements.txt deploy /opt/ccl-mohawk/
   sudo python3 -m venv /opt/ccl-mohawk/.venv
   sudo /opt/ccl-mohawk/.venv/bin/pip install -r /opt/ccl-mohawk/requirements.txt
   sudo cp .env.example /opt/ccl-mohawk/.env
   sudo chmod 600 /opt/ccl-mohawk/.env
   sudo chown -R mohawk:mohawk /opt/ccl-mohawk
   ```
4. Edit `/opt/ccl-mohawk/.env` as root. Configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_USERNAME`, `SMTP_PASSWORD`, and `SMTP_FROM` for your email provider. Set `DRY_RUN=0` after testing. `ALERT_TO` defaults to `l55eko@icloud.com`. Use an SMTP app password, not your personal email password, where supported.
5. Install service:
   ```bash
   sudo cp /opt/ccl-mohawk/deploy/mohawk.service /etc/systemd/system/
   sudo systemctl daemon-reload
   sudo systemctl enable --now mohawk
   sudo journalctl -u mohawk -f
   ```
6. For a manual scanner test, run with `RUN_ONCE=1 DRY_RUN=1` (and other env variables loaded) and review logs. For an email test, configure SMTP and use `python -c "from bot import send_email; send_email('Mohawk test','Email alerts are working')"` with `DRY_RUN=0` in the environment.

## How it works
- Runs persistently, checks during 12:00–15:00 UK time (warm-up starts at noon), November 23–30, 2026.
- Checks CCL homepage and deals page every cycle, plus a prioritised, persistent frontier of relevant links. Defaults to 45 pages/cycle, at least 1.5 seconds between requests, and 45 seconds between cycles.
- Extracts likely clue text and prioritises nearby product links; checks structured Product JSON-LD for exactly GBP 1.00 and a desktop/gaming PC product name.
- Sends clue alerts and verified-product alerts to iCloud, with direct links. SQLite prevents repeat emails across restarts.
- Will **miss** some image-only clues, JavaScript-rendered listings, or puzzles requiring human interpretation. It does not scan every CCL page, and no £1 listing is guaranteed.

## Operational notes
- The bot **does not deploy itself**. VM setup and SMTP credentials are required.
- Email may be delayed by provider delivery and iOS push behaviour.
- If CCL disallows automation, disable the service. Do not increase rate limits to evade blocks.
- No card details or CCL credentials are needed.
- `DRY_RUN=1` logs alerts without sending; `DRY_RUN=0` enables sending.
- Run `python -m pytest -q` for tests.

## v4: public source-code and clue change intelligence

The bot now snapshots the visible page content in SQLite and compares subsequent visits. Newly appearing Mohawk/£1/PC text generates a **NEW/CHANGED CLUE** email with a direct URL. It also inspects publicly embedded JSON/JSON-LD and page metadata for clues and modification hints. This is **not** a way to know when a page was edited on CCL's servers: timestamps and page differences are only hints, and the first visit establishes a baseline. It does not inspect private source repositories, circumvent access restrictions, or fetch inaccessible pages. It still cannot interpret clues embedded solely in images or JS-rendered DOM. Avoid excessive polling and respect robots.txt and CCL's promotion rules.

## V5: supplied Mohawk logo and clue interpretation

The attached official-looking logo reference is included at `assets/mohawk-reference.jpg`.
The bot now checks same-domain images on visited pages against a perceptual hash
of that logo. A match boosts the enclosing link to the front of the crawl queue
and sends an email with the image, page, link, nearby text and ranked next steps.

**Optional AI:** Add `OPENAI_API_KEY` to `.env` to rank *existing, observed*
links based on the surrounding clue text using the Responses API. This incurs
API costs and is not needed for basic logo detection. Without a key, the bot
uses a transparent keyword heuristic, not an AI riddle solver.

**Limitations:** This compares whole images, so small logo overlays, crops,
CSS background images, lazy JavaScript images, and visually modified versions
may be missed. There is no Playwright screenshot or computer vision region
search yet. The logo might be decorative rather than a genuine clue. Pages
must be discovered first, and no complete site scan or win is guaranteed.
The bot reads public HTML and images only, respects robots.txt and rate limits,
and does not buy products. Check CCL competition rules before deployment.

**Quick test:** `pip install -r requirements.txt && pytest -q`.
**Security:** Never commit `.env` or API/SMTP credentials. Run first with
`DRY_RUN=1` and `RUN_ONCE=1`, inspect logs, then test email separately.

## v6: Browser rendering and logo recognition inside banners

- `ENABLE_BROWSER=1` enables Playwright rendering for high-priority pages, including JavaScript-inserted text and images.
- `ENABLE_PARTIAL_IMAGE_MATCH=1` enables OpenCV ORB feature detection for the Mohawk logo appearing inside larger images.
- Install dependencies with `pip install -r requirements.txt && python -m playwright install --with-deps chromium` on Ubuntu. Browser dependencies increase RAM use; test on the actual Oracle instance.
- Image recognition is heuristic. A positive result is a lead, **not proof** that a page contains the winning PC.
- Rendered pages are checked only for high-priority URLs to reduce load. This is not a full-site browser crawl.
- The service is deliberately conservative: public pages only, robots.txt respected by the crawler, no CAPTCHA bypass, no login or purchase.
- AI clue ranking requires an `OPENAI_API_KEY`, an API-funded account and candidate links. Without it, keyword ranking is used. The bot cannot guarantee finding the £1 PC or being first.
- `DRY_RUN=1` prints alerts without emailing. Set to `0` only after testing SMTP. Never commit `.env` or secrets.
