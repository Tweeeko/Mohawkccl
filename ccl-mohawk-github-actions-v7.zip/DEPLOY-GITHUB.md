# Deploy CCL Mohawk Finder with GitHub Actions

1. Keep your repository **private**. Extract the supplied ZIP locally, then upload the **contents of the `ccl-mohawk-pro` folder** to the repository root (not the ZIP itself). GitHub's normal upload does **not** extract ZIPs. The workflow must end up at `.github/workflows/mohawk-hunt.yml` and `bot.py` at the root.
2. In GitHub repository **Settings → Secrets and variables → Actions → New repository secret**, add `SMTP_HOST`, `SMTP_USERNAME`, `SMTP_PASSWORD`, and optionally `SMTP_PORT` (default 465) and `SMTP_FROM`. The receiving email is preset to `l55eko@icloud.com`. Use an email provider's app password/token, not your primary account password. Never commit secrets.
3. Optional: add `OPENAI_API_KEY` for paid AI clue interpretation. Without it, the bot uses heuristic interpretation.
4. Open **Actions → CCL Mohawk Hunt → Run workflow** for a manual start. Automatic scheduling is configured for 12:55 UTC on 23–30 November 2026, which is 12:55 UK time. GitHub may delay or drop scheduled starts; manually triggering at 12:55 is more reliable.
5. Watch Actions logs. An SMTP configuration check prevents silently running without email credentials. A successful job/test does not prove actual email delivery or that the bot will find the promotion.

## Limitations
- The code runs only during 13:00–15:00 UK time, 23–30 Nov 2026, even if manually triggered outside that window. A manual run before the window stays active until cancelled or timed out.
- GitHub-hosted runner is ephemeral. State is not preserved between daily runs; an SQLite artifact is uploaded for troubleshooting, not restored automatically.
- Scheduled workflows on GitHub may be delayed, particularly under load. The 2-hour hunt fits within a single job's configured 155-minute timeout if it starts near 12:55.
- Bot obeys robots.txt and stops a cycle on access-denied/rate-limited responses. No CAPTCHA bypass or checkout automation.
- No live end-to-end verification against CCL or SMTP has been performed. Site structure and rules may change. Ensure use complies with promotion terms.
