"""CCL clue-guided, polite monitor. Never orders or bypasses access controls."""
import os, re, json, time, sqlite3, logging, smtplib, ssl, hashlib
from collections import deque
from datetime import datetime
from email.message import EmailMessage
from urllib.parse import urljoin, urlsplit, urlunsplit
from urllib.robotparser import RobotFileParser
from zoneinfo import ZoneInfo
import requests
from intelligence import analyse
from vision_clues import image_candidates, logo_match, reference_hash, interpret_clue
from browser_intelligence import render_public_page, partial_logo_match
from bs4 import BeautifulSoup

BASE='https://www.cclonline.com/'
SEEDS=[BASE, urljoin(BASE,'all-deals/')]
UA='CCLMohawkFinder/3.0 (personal competition link monitoring)'
CLUE=re.compile(r'\b(?:mohawk|treasure hunt|find the pc|hidden pc|first clue|next clue)\b|£\s*1\s*(?:gaming\s*)?pc',re.I)
PC=re.compile(r'\b(?:gaming\s+pc|desktop\s+pc|pre[- ]?built\s+(?:gaming\s+)?pc|gaming\s+desktop|computer\s+system|workstation\s+pc)\b',re.I)
PRICE=re.compile(r'(?<!\d)(?:£\s*1(?:[.,]00)?|GBP\s*1(?:[.,]00)?)(?!\d)',re.I)
BAD=re.compile(r'/(?:basket|cart|checkout|account|login|register|wishlist)(?:/|$)',re.I)
LOG=logging.getLogger('mohawk')

def setting(name, default): return os.getenv(name,str(default))
def safe_url(href,parent=BASE):
    try:
        p=urlsplit(urljoin(parent,href))
        if p.scheme!='https' or p.hostname not in ('www.cclonline.com','cclonline.com') or BAD.search(p.path): return None
        return urlunsplit((p.scheme,p.netloc,p.path or '/',p.query,''))
    except ValueError: return None

def products(soup):
    def walk(obj):
        if isinstance(obj,list):
            for v in obj: yield from walk(v)
        elif isinstance(obj,dict):
            typ=obj.get('@type','')
            if typ=='Product' or (isinstance(typ,list) and 'Product' in typ): yield obj
            for v in obj.values():
                if isinstance(v,(dict,list)): yield from walk(v)
    for script in soup.select('script[type="application/ld+json"]'):
        try: yield from walk(json.loads(script.string or script.get_text()))
        except (ValueError,TypeError): pass

def confirmed(soup,url):
    """Structured Product offer only; no misleading £1 shipping/discount text."""
    for p in products(soup):
        name=str(p.get('name',''))
        if not PC.search(name) or re.search(r'\b(?:mouse|keyboard|mat|case|cable|adapter|headset|monitor|stand|fan|power supply)\b',name,re.I): continue
        offers=p.get('offers',[])
        if isinstance(offers,dict): offers=[offers]
        for offer in offers:
            if not isinstance(offer,dict): continue
            try: price=float(str(offer.get('price','')).replace(',','.'))
            except ValueError: continue
            if price==1 and str(offer.get('priceCurrency','GBP')).upper()=='GBP':
                return name,safe_url(str(p.get('url') or url),url) or url
    return None

def send_email(subject,body):
    if setting('DRY_RUN','1')=='1': LOG.warning('DRY RUN ALERT: %s\n%s',subject,body); return True
    host=os.getenv('SMTP_HOST'); user=os.getenv('SMTP_USERNAME'); password=os.getenv('SMTP_PASSWORD')
    if not (host and user and password): LOG.error('Missing SMTP configuration'); return False
    msg=EmailMessage(); msg['From']=os.getenv('SMTP_FROM') or user
    msg['To']=setting('ALERT_TO','l55eko@icloud.com'); msg['Subject']=subject; msg.set_content(body)
    try:
        port=int(setting('SMTP_PORT',465) or 465)
        if port==465:
            with smtplib.SMTP_SSL(host,port,context=ssl.create_default_context(),timeout=15) as s:
                s.login(user,password); s.send_message(msg)
        else:
            with smtplib.SMTP(host,port,timeout=15) as s:
                s.starttls(context=ssl.create_default_context()); s.login(user,password); s.send_message(msg)
        return True
    except Exception: LOG.exception('Email failed'); return False

class Finder:
    def __init__(self, db='state.sqlite3'):
        self.db=sqlite3.connect(db)
        self.db.execute('create table if not exists seen (kind text, id text, primary key(kind,id))')
        self.db.execute('create table if not exists frontier (url text primary key, priority integer, last_seen integer default 0)')
        self.db.execute('create table if not exists snapshots (url text primary key, digest text, content text, checked integer)')
        self.db.commit()
        self.session=requests.Session(); self.session.headers.update({'User-Agent':UA,'Accept-Language':'en-GB,en;q=0.9'})
        self.robots=RobotFileParser(); self.robots.set_url(urljoin(BASE,'robots.txt'))
        self.last_request=0
        self.logo_hash=reference_hash(os.path.join(os.path.dirname(__file__),"assets","mohawk-reference.jpg"))
        self.image_checked=set()
        try:
            r=self.session.get(self.robots.url,timeout=12); r.raise_for_status()
            self.robots.parse(r.text.splitlines()); self.allowed=True
        except requests.RequestException:
            LOG.error('Cannot retrieve robots.txt; fail closed'); self.allowed=False
        for u in SEEDS: self.enqueue(u,100)
    def enqueue(self,url,priority):
        url=safe_url(url)
        if not url:return
        if self.db.execute('select count(*) from frontier').fetchone()[0]>=int(setting('MAX_QUEUE',3000)):return
        self.db.execute('insert into frontier(url,priority) values (?,?) on conflict(url) do update set priority=max(priority,excluded.priority)',(url,priority)); self.db.commit()
    def once(self,kind,id,subject,body):
        if self.db.execute('select 1 from seen where kind=? and id=?',(kind,id)).fetchone():return
        if send_email(subject,body):
            self.db.execute('insert or ignore into seen values (?,?)',(kind,id)); self.db.commit()
    def fetch(self,url):
        if not self.allowed or not self.robots.can_fetch(UA,url):return None
        delay=max(1.5,float(setting('REQUEST_DELAY_SECONDS',2)))
        wait=self.last_request+delay-time.monotonic()
        if wait>0:time.sleep(wait)
        self.last_request=time.monotonic()
        try:
            r=self.session.get(url,timeout=15,allow_redirects=False)
            if r.status_code in (403,429): LOG.warning('Blocked or rate limited (%s); stop cycle',r.status_code); self.blocked=True; return None
            if r.status_code!=200 or 'text/html' not in r.headers.get('Content-Type',''):return None
            if len(r.content)>3_000_000:return None
            return r.text
        except requests.RequestException as e:LOG.warning('Fetch failed %s: %s',url,e); return None
    def cycle(self):
        if not self.allowed:return
        self.blocked=False; now=int(time.time())
        # Revisit high-value pages every cycle; revisit other pages less frequently.
        for seed in SEEDS:self.db.execute('update frontier set last_seen=0 where url=?',(seed,))
        self.db.commit()
        limit=int(setting('MAX_PAGES_PER_CYCLE',45)); count=0
        rows=self.db.execute('select url,priority from frontier where last_seen=0 or last_seen<? order by priority desc,last_seen asc limit ?', (now-600,limit)).fetchall()
        for url,priority in rows:
            if self.blocked:break
            self.db.execute('update frontier set last_seen=? where url=?',(now,url)); self.db.commit()
            html=self.fetch(url)
            if html is None:continue
            # Browser rendering is optional and only used on high-priority pages.
            browser_matches=[]
            if setting('ENABLE_BROWSER','0')=='1' and priority>=int(setting('BROWSER_MIN_PRIORITY',90)):
                try:
                    html,browser_matches=render_public_page(url,os.path.join(os.path.dirname(__file__),'assets','mohawk-reference.jpg'))
                except Exception as exc:
                    LOG.warning('Browser rendering failed (%s); falling back to HTML',type(exc).__name__)
            soup=BeautifulSoup(html,'html.parser')
            count+=1
            old=self.db.execute('select content from snapshots where url=?',(url,)).fetchone()
            intelligence=analyse(html,old[0] if old else None)
            self.db.execute('insert into snapshots(url,digest,content,checked) values(?,?,?,?) on conflict(url) do update set digest=excluded.digest,content=excluded.content,checked=excluded.checked',(url,intelligence['digest'],intelligence['snapshot'],now))
            self.db.commit()
            if old and intelligence['changed_clues']:
                digest=hashlib.sha256((url+'\n'+'\n'.join(intelligence['changed_clues'])).encode()).hexdigest()
                self.once('change',digest,'CCL NEW/CHANGED CLUE — CHECK NOW',f'Page: {url}\nNew or changed text (not proof of server edit time):\n'+'\n'.join(intelligence['changed_clues']))
            if intelligence['json_clues'] and not old:
                LOG.info('Clue-related public JSON found at %s',url)
            found=confirmed(soup,url)
            if found:
                name,link=found
                self.once('pc',link,'CCL £1 PC FOUND — OPEN NOW',f'Product: {name}\nPrice: £1 (structured product listing)\nDirect link: {link}\nCheck price and availability before checkout.')
            # Find clue-bearing text, avoiding unrelated full-page product grids.
            clue_texts=[]
            for el in soup.select('h1,h2,h3,p,li,a,div[class*=clue],section[class*=clue]'):
                txt=' '.join(el.get_text(' ',strip=True).split())
                if 8<=len(txt)<=450 and CLUE.search(txt):clue_texts.append(txt)
            if clue_texts:
                unique=list(dict.fromkeys(clue_texts))[:8]
                digest=hashlib.sha256((url+'\n'+'\n'.join(unique)).encode()).hexdigest()
                self.once('clue',digest,'CCL Mohawk clue spotted',f'Page: {url}\n\n'+'\n\n'.join(unique))
            # Recognise supplied Mohawk logo in public page images. A matching
            # image marks its enclosing link and nearby text as a clue candidate.
            matches=list(browser_matches)
            for candidate in image_candidates(soup,url)[:int(setting('MAX_IMAGES_PER_PAGE',12))]:
                image_url=candidate['image']
                if image_url in self.image_checked:continue
                self.image_checked.add(image_url)
                # Same-site images only; do not crawl external CDNs without permission.
                if not safe_url(image_url,url):continue
                if not self.robots.can_fetch(UA,image_url):continue
                wait=self.last_request+max(1.5,float(setting('REQUEST_DELAY_SECONDS',2)))-time.monotonic()
                if wait>0:time.sleep(wait)
                self.last_request=time.monotonic()
                try:
                    response=self.session.get(image_url,timeout=10,allow_redirects=False)
                    if response.status_code in (403,429):self.blocked=True;break
                    if response.status_code!=200 or not response.headers.get('Content-Type','').startswith('image/') or len(response.content)>1_500_000:continue
                    if logo_match(response.content,self.logo_hash) or (setting('ENABLE_PARTIAL_IMAGE_MATCH','0')=='1' and partial_logo_match(response.content,os.path.join(os.path.dirname(__file__),'assets','mohawk-reference.jpg'))>=12):
                        matches.append(candidate)
                        dest=safe_url(candidate['target'],url)
                        if dest:self.enqueue(dest,120)
                except requests.RequestException:pass
            if matches:
                clue='\n'.join(x['text'] for x in matches)
                candidates=[safe_url(a.get('href',''),url) for a in soup.select('a[href]')]
                candidates=[x for x in candidates if x]
                interpretation=interpret_clue(clue,candidates)
                for dest in interpretation['ranked_urls'][:8]:self.enqueue(dest,110)
                digest=hashlib.sha256((url+repr(matches)).encode()).hexdigest()
                body='Logo detected on: '+url+'\n\n'+'\n'.join('Image: '+x['image']+'\nLink: '+x['target']+'\nContext: '+x['text'] for x in matches)+'\n\nInterpretation ('+interpretation['method']+'): '+interpretation['reasoning']+'\nSuggested links:\n'+'\n'.join(interpretation['ranked_urls'][:8])
                self.once('logo',digest,'CCL MOHAWK LOGO FOUND — FOLLOW THIS LINK',body)
            # Prioritise links surrounding clues, then PC product links and category listings.
            for a in soup.select('a[href]'):
                dest=safe_url(a.get('href',''),url)
                if not dest:continue
                label=' '.join(a.get_text(' ',strip=True).split())[:220]
                context=' '.join(a.parent.get_text(' ',strip=True).split())[:400] if a.parent else label
                score=5
                if CLUE.search(label+' '+context):score=95
                elif PC.search(label):score=70
                elif '/gaming-pcs/' in dest or '/pc/' in dest:score=55
                elif any(x in dest for x in ('deals','offers','gaming')):score=30
                if score>=30:self.enqueue(dest,score)
        LOG.info('Cycle fetched %s pages; frontier %s',count,self.db.execute('select count(*) from frontier').fetchone()[0])

def active():
    now=datetime.now(ZoneInfo(setting('TIMEZONE','Europe/London')))
    return now.year==2026 and now.month==11 and 23<=now.day<=30 and 13<=now.hour<15

def main():
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    finder=Finder()
    if setting('RUN_ONCE',0)=='1':finder.cycle();return
    while True:
        now=datetime.now(ZoneInfo(setting('TIMEZONE','Europe/London')))
        if now.year!=2026 or now.month!=11 or now.day<23 or now.day>30 or now.hour>=15:
            LOG.info('Outside 2026 hunt dates or hunt has ended; exiting')
            return
        if active():finder.cycle()
        time.sleep(max(20,int(setting('CHECK_INTERVAL_SECONDS',45))))

if __name__=='__main__':main()
