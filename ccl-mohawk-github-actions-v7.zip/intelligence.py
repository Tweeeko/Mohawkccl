"""Public-page change detection and clue extraction. No private APIs or bypasses."""
import hashlib, json, re
from difflib import SequenceMatcher
from bs4 import BeautifulSoup

KEYWORDS=re.compile(r'\b(mohawk|treasure|hunt|clue|hidden|find|one pound|gaming pc|desktop pc)\b|£\s*1(?:\.00)?',re.I)
DATE_HINT=re.compile(r'(?:dateModified|datePublished|lastmod|updated|modified)',re.I)

def analyse(html, previous=None):
    soup=BeautifulSoup(html,'html.parser')
    for tag in soup(['style','noscript','svg']):tag.decompose()
    # Main content text avoids changes from rotating banners and navigation.
    main=soup.select_one('main') or soup.select_one('[role=main]') or soup.body or soup
    lines=[]
    for tag in main.select('h1,h2,h3,h4,p,li,a,article,section'):
        if tag.name in ('article','section') and tag.find(['p','li','h2','h3']):continue
        s=' '.join(tag.get_text(' ',strip=True).split())
        if 12<=len(s)<=350 and s not in lines:lines.append(s)
    clues=[s for s in lines if KEYWORDS.search(s)]
    scripts=[]
    for s in soup.select('script[type="application/ld+json"],script[type="application/json"],script#__NEXT_DATA__'):
        raw=s.string or s.get_text()
        if not raw or len(raw)>400000:continue
        try:
            obj=json.loads(raw)
            rendered=json.dumps(obj,ensure_ascii=False)
            if KEYWORDS.search(rendered):scripts.append(rendered[:1500])
        except ValueError:pass
    hints=[]
    for meta in soup.select('meta[property],meta[name]'):
        name=meta.get('property') or meta.get('name','')
        if DATE_HINT.search(name):hints.append(f'{name}: {meta.get("content","")[:100]}')
    snapshot='\n'.join(lines)
    digest=hashlib.sha256(snapshot.encode()).hexdigest()
    old=previous or ''
    oldset=set(old.splitlines())
    new_lines=[s for s in lines if s not in oldset]
    changed=[s for s in new_lines if KEYWORDS.search(s)]
    return {'digest':digest,'snapshot':snapshot[:100000],'clues':clues[:15], 'changed_clues':changed[:15], 'json_clues':scripts[:3], 'date_hints':hints[:8], 'changed':bool(previous is not None and snapshot!=previous), 'similarity':round(SequenceMatcher(None,old[:10000],snapshot[:10000]).ratio(),3) if previous is not None else None}
