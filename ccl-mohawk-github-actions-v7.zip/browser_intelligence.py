"""Optional rendered-page inspection and local partial-logo detection.
Only public pages. Never signs in, buys, or circumvents challenges.
"""
import io, logging, os
from urllib.parse import urljoin
from PIL import Image
LOG=logging.getLogger('mohawk.browser')

def partial_logo_match(image_bytes, reference_path, min_good=12):
    """ORB feature matching; works with resized/cropped logos in larger images.
    Returns a score, not a guarantee. Requires optional opencv-python-headless.
    """
    try:
        import cv2
        import numpy as np
        ref=cv2.imread(reference_path,cv2.IMREAD_GRAYSCALE)
        target=cv2.imdecode(np.frombuffer(image_bytes,dtype=np.uint8),cv2.IMREAD_GRAYSCALE)
        if ref is None or target is None:return 0
        orb=cv2.ORB_create(nfeatures=1800,fastThreshold=8)
        k1,d1=orb.detectAndCompute(ref,None); k2,d2=orb.detectAndCompute(target,None)
        if d1 is None or d2 is None:return 0
        matcher=cv2.BFMatcher(cv2.NORM_HAMMING)
        pairs=matcher.knnMatch(d1,d2,k=2)
        good=[a for a,b in pairs if a.distance < .72*b.distance]
        if len(good)<min_good:return len(good)
        src=np.float32([k1[m.queryIdx].pt for m in good]).reshape(-1,1,2)
        dst=np.float32([k2[m.trainIdx].pt for m in good]).reshape(-1,1,2)
        matrix,mask=cv2.findHomography(src,dst,cv2.RANSAC,5.0)
        if matrix is None or mask is None:return 0
        inliers=int(mask.sum())
        return inliers if inliers>=min_good else 0
    except Exception:
        return 0

def render_public_page(url, reference_path, timeout_ms=12000):
    """Returns rendered HTML and candidate linked logo screenshots.
    Browser loads a public page without clicking or solving access challenges.
    """
    from playwright.sync_api import sync_playwright
    matches=[]
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,args=['--no-sandbox'])
        try:
            page=browser.new_page(viewport={'width':1365,'height':900},device_scale_factor=1)
            page.goto(url,wait_until='domcontentloaded',timeout=timeout_ms)
            page.wait_for_timeout(1000)
            html=page.content()
            for img in page.locator('img').all()[:25]:
                try:
                    if not img.is_visible():continue
                    src=img.get_attribute('src') or ''
                    if not src:continue
                    pixels=img.screenshot(timeout=2500)
                    score=partial_logo_match(pixels,reference_path)
                    if score>=12:
                        link=img.locator('xpath=ancestor::a[1]')
                        href=link.get_attribute('href') if link.count() else None
                        matches.append({'image':urljoin(url,src),'target':urljoin(url,href) if href else url,'score':score,'text':img.get_attribute('alt') or ''})
                except Exception:continue
            return html,matches
        finally:browser.close()
