from intelligence import analyse

def test_change_clue():
    before='<main><p>Welcome to our latest computer deals and offers.</p></main>'
    after='<main><p>Welcome to our latest computer deals and offers.</p><p>Mohawk clue: follow the blue desktop PC.</p></main>'
    old=analyse(before)['snapshot']
    result=analyse(after,old)
    assert result['changed']
    assert 'Mohawk clue' in result['changed_clues'][0]

def test_metadata_not_proof():
    result=analyse('<html><head><meta property="article:modified_time" content="2026-11-23"></head><body><main><p>Some gaming PC offers available today.</p></main></body></html>')
    assert result['date_hints']
