from pathlib import Path
from browser_intelligence import partial_logo_match

def test_partial_logo_inside_larger_image():
    from PIL import Image
    import io
    ref=Path(__file__).resolve().parents[1]/'assets'/'mohawk-reference.jpg'
    logo=Image.open(ref).convert('RGB')
    canvas=Image.new('RGB',(1400,1000),'#dddddd')
    canvas.paste(logo.resize((520,520)),(300,200))
    data=io.BytesIO();canvas.save(data,format='JPEG',quality=92)
    assert partial_logo_match(data.getvalue(),str(ref))>=12

def test_blank_image_is_not_logo():
    from PIL import Image
    import io
    ref=Path(__file__).resolve().parents[1]/'assets'/'mohawk-reference.jpg'
    data=io.BytesIO();Image.new('RGB',(800,600),'white').save(data,format='PNG')
    assert partial_logo_match(data.getvalue(),str(ref))==0
