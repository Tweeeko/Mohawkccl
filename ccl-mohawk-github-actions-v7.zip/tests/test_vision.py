from vision_clues import reference_hash,logo_match,image_candidates,interpret_clue
from bs4 import BeautifulSoup
from pathlib import Path
P=Path(__file__).resolve().parents[1]/'assets'/'mohawk-reference.jpg'
def test_reference_logo():
    assert logo_match(P.read_bytes(),reference_hash(P))
def test_img_link():
    soup=BeautifulSoup('<a href="/test/"><img src="/logo.jpg" alt="Follow the Mohawk"></a>','html.parser')
    assert image_candidates(soup,'https://www.cclonline.com/')[0]['target']=='https://www.cclonline.com/test/'
def test_fallback_rank():
    assert interpret_clue('blue graphics', ['https://www.cclonline.com/blue-graphics/','https://www.cclonline.com/other/'])['ranked_urls'][0].endswith('blue-graphics/')
