from bs4 import BeautifulSoup
from bot import confirmed,safe_url

def test_verified_pc():
    html='<script type="application/ld+json">{"@type":"Product","name":"Horizon Gaming PC","offers":{"price":"1.00","priceCurrency":"GBP"}}</script>'
    assert confirmed(BeautifulSoup(html,'html.parser'),'https://www.cclonline.com/item/')[0]=='Horizon Gaming PC'
def test_not_accessory():
    html='<script type="application/ld+json">{"@type":"Product","name":"Gaming PC mouse","offers":{"price":"1.00","priceCurrency":"GBP"}}</script>'
    assert confirmed(BeautifulSoup(html,'html.parser'),'https://www.cclonline.com/item/') is None
def test_domain():
    assert safe_url('https://evil.example/x') is None
    assert safe_url('/checkout/') is None
