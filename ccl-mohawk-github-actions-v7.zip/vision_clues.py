"""Public page logo matching and optional AI clue reasoning. No authentication bypass."""
import io, os, re, json, hashlib, logging
from urllib.parse import urljoin
import requests
from PIL import Image, ImageOps
from bs4 import BeautifulSoup
LOG=logging.getLogger('mohawk.vision')

def dhash(img):
    im=ImageOps.grayscale(img).resize((9,8))
    px=list(im.getdata())
    return sum((px[y*9+x]>px[y*9+x+1]) << (y*8+x) for y in range(8) for x in range(8))

def distance(a,b):return (a^b).bit_count()

def logo_match(data,reference,threshold=12):
    """Compares complete image to reference; cropped/overlaid logos can be missed."""
    try:
        im=Image.open(io.BytesIO(data)).convert('RGB')
        if im.width<80 or im.height<80:return False
        return distance(dhash(im),reference)<=threshold
    except Exception:return False

def reference_hash(path):
    with Image.open(path) as im:return dhash(im.convert('RGB'))

def image_candidates(soup,page):
    """Return image URLs with nearby text and enclosing links, including lazy loading."""
    out=[]
    for img in soup.select('img'):
        src=img.get('src') or img.get('data-src') or img.get('data-lazy-src')
        if not src:continue
        parent=img.find_parent('a',href=True)
        text=' '.join((img.get('alt','')+' '+(parent.get_text(' ',strip=True) if parent else '')+' '+(img.parent.get_text(' ',strip=True) if img.parent else '')).split())[:600]
        out.append({'image':urljoin(page,src),'target':urljoin(page,parent['href']) if parent else page,'text':text})
    return out

def interpret_clue(text,links):
    """Optional OpenAI reasoning; fallback to transparent keyword ranking."""
    links=list(dict.fromkeys(links))[:35]
    key=os.getenv('OPENAI_API_KEY','')
    if key and text.strip():
        try:
            payload={'model':os.getenv('AI_MODEL','gpt-4.1-mini'),'input':[{'role':'system','content':'You interpret UK retail treasure-hunt clues. Only use supplied candidate URLs. Return a JSON object with keys reasoning (brief), ranked_urls (array of URLs). Do not invent URLs or assert a winning item.'},{'role':'user','content':json.dumps({'clue':text[:2000],'candidate_urls':links})}], 'text':{'format':{'type':'json_object'}},'max_output_tokens':450}
            r=requests.post('https://api.openai.com/v1/responses',headers={'Authorization':'Bearer '+key},json=payload,timeout=18)
            r.raise_for_status()
            body=r.json(); parts=[c.get('text','') for item in body.get('output',[]) for c in item.get('content',[]) if c.get('type')=='output_text']
            obj=json.loads(''.join(parts)); ranked=[u for u in obj.get('ranked_urls',[]) if u in links]
            return {'ranked_urls':ranked,'reasoning':str(obj.get('reasoning',''))[:400],'method':'AI'}
        except Exception as e:LOG.warning('AI unavailable; using keyword ranking: %s',type(e).__name__)
    words=set(re.findall(r'[a-z0-9]{4,}',text.lower()))-{'this','that','with','from','your','clue','mohawk','follow','find','next'}
    return {'ranked_urls':sorted(links,key=lambda u:sum(w in u.lower().replace('-',' ') for w in words),reverse=True)[:10], 'reasoning':'Keyword URL relevance only; not genuine riddle solving','method':'heuristic'}
